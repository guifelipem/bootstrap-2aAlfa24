import java.util.Scanner;

public class ex8 {
    public static void main(String[] args) {
        ex08();
    }

    private static void ex08() {
        System.out.println("Exercício 8");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Informe um número: ");
        int numero = scanner.nextInt();
        int anterior1 = 0, anterior2 = 1, soma = 1;
        for(int contador = 1; contador <= numero; contador++) {
            System.out.println(soma);
            soma = anterior1 + anterior2;
            anterior1 = anterior2;
            anterior2 = soma;
        }
    }
}
