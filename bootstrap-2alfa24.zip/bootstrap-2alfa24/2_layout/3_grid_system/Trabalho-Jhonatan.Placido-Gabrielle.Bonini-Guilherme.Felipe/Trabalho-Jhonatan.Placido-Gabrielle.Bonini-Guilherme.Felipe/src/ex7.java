import java.util.Scanner;

public class ex7 {
    public static void main(String[] args){
        System.out.println("Média de Notas");

        Scanner objetoScanner = new Scanner(System.in);

        System.out.println("Informe a 1° nota: ");
        float nota1 = objetoScanner.nextFloat();
        System.out.println("Informe a 2° nota: ");
        float nota2 = objetoScanner.nextFloat();
        System.out.println("Informe a 3° nota: ");
        float nota3 = objetoScanner.nextFloat();
        System.out.println("Informe a 4° nota: ");
        float nota4 = objetoScanner.nextFloat();

        float media = (nota1 + nota2 + nota3 + nota4) / 4;

        if (media >= 7.0) {
            System.out.println("Aluno Aprovado!! :D");
        } else {
            System.out.println("Aluno reprovado!");
        }
    }
}
