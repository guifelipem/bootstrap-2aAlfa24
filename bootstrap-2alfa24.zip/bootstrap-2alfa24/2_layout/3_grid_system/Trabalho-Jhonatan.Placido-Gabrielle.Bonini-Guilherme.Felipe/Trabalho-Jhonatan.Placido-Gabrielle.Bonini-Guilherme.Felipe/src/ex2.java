import java.util.Scanner;

public class ex2 {
    public static void main(String[] args) {
        System.out.println("Numeros pares e ímpares");
        executarFor();
    }

    private static void executarFor() {

        Scanner objetoScanner = new Scanner(System.in);

        for (int contador = 0; contador < 10; contador++) {
            System.out.println("Digite um número: ");
            int numero = objetoScanner.nextInt();

            if ((numero % 2) == 0) System.out.println("Par");
            if ((numero % 2) == 1) System.out.println("Ímpar");
        }
    }
}