import java.util.Random;
import java.util.Scanner;

public class ex5 {

    public class exercicio5 {
        public static void main(String[] args) {
            ex05();
        }

        private static void ex05() {
            System.out.println("Exercício 5");
            System.out.println("O computador sorteou um número aleátorio de 0 a 1000.");
            System.out.println("Você tem 10 chances para acertar. Boa sorte!");

            Scanner scanner = new Scanner(System.in);
            Random random = new Random();
            int numero = random.nextInt(1000);
            System.out.println(numero);
            int contador = 1, tentativa;
            do {
                System.out.println("Adivinhe um número de 0 a 1000: ");
                tentativa = scanner.nextInt();

                if (tentativa == numero) {
                    System.out.println("Parabéns! Você acertou na sua " + contador + "° tentativa!");
                } else if (contador == 10) {
                    System.out.println("Ops! Número errado! Infelizmente acabaram suas tentativas. O número era " + numero + ". Mais sorte na próxima!");
                } else {
                    System.out.println("Ops! Número errado! Ainda restam " + (10 - contador) + " tentativas. Tente novamente.");
                }

                contador++;
            } while((tentativa != numero) & (contador <= 10));
        }
    }
}
