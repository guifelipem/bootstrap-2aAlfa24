import java.util.Scanner;

public class ex3 {
    public static void main(String[] args) {
        ex03();
    }

    private static void ex03() {
        System.out.println("Exercício 3.");
        System.out.println("Informe um número: ");
        Scanner Scanner = new Scanner(System.in);

        int numero = Scanner.nextInt();
        for(int contador = 2; contador <= numero; contador++) {
            boolean condicao = (contador == 2 || contador == 3 || contador == 5 || contador == 7 || contador == 11) || (((contador % 2) != 0) && ((contador % 3) != 0) && ((contador % 5) != 0) & ((contador % 7) != 0 )& ((contador % 11) != 0));
            if (condicao) {
                System.out.print(contador + " ");
            }
        }
    }
}

