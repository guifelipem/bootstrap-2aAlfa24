import java.util.Scanner;

public class ex1 {

    public static void main(String[] args) {
        System.out.println("Números positivos e negativos");
        executarA();
    }

    private static void executarA (){
        Scanner objetoScanner = new Scanner(System.in);
        System.out.println("Informe um número:");
        int numero = objetoScanner.nextInt();
        if (numero > 0) {
            System.out.println("O número "+numero+" é positivo");
        } else if (numero < 0) {
            System.out.println("O número "+numero+" é negativo");
        } else {
            System.out.println("O número digitado foi 0 ");
        }

    }
}
