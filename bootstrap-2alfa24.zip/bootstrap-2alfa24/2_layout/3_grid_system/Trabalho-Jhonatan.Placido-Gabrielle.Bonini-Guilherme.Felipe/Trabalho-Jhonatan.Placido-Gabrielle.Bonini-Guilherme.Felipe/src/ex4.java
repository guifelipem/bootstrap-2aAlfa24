import java.util.Scanner;

public class ex4 {

    public static void main(String[] args){
        executarB();
    }

    private static void executarB(){

        Scanner objetoScanner = new Scanner (System.in);

        System.out.println("Informe o primeiro número:");
        int  n1 = objetoScanner.nextInt();
        System.out.println("Qual operação deseja realizar?");
        String operador = objetoScanner.next();
        System.out.println("Informe o segundo número:");
        int  n2 = objetoScanner.nextInt();


        if (operador.equals("+")){
            int resultado = n1+n2;
            System.out.println("O resultado da soma entre o números " +n1+" e "+n2+" é "+resultado);
        } else if (operador.equals("-")) {
            int resultado = n1-n2;
            System.out.println("O resultado da subtração entre o números " +n1+" e "+n2+" é "+resultado);
        } else if (operador.equals("*")) {
            int resultado = n1*n2;
            System.out.println("O resultado da multiplicação entre o números " +n1+" e "+n2+" é "+resultado);
        } else {
            int resultado = n1/n2;
            System.out.println("O resultado da divisão entre o números " +n1+" e "+n2+" é "+resultado);
        }

    }
}
