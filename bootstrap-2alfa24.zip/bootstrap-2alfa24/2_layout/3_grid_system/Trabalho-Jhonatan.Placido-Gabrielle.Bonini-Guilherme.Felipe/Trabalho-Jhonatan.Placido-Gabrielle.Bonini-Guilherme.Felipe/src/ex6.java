import java.util.Scanner;

public class ex6 {

    public static void main(String[] args){
        executarC();
    }

    private static void executarC () {
        Scanner objetoScanner =  new Scanner(System.in);

        System.out.println("Informe um número:");
        int numero = objetoScanner.nextInt();

        System.out.println("A tabuada do número "+numero+" é:");
        for (int i = 0; i <= 10 ; i++) {
            int multiplicacao = numero*i;
            System.out.println(numero+"X" + i +"=" + multiplicacao);
        }
    }
}
